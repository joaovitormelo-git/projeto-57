const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database/db');
const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

// Rota inicial: lista de tarefas
app.get('/', (req, res) => {
  db.all('SELECT * FROM tarefas', (err, rows) => {
    if (err) throw err;
    res.render('index', { tarefas: rows });
  });
});

// Formulário para adicionar tarefa
app.get('/add', (req, res) => {
  res.render('add');
});

// Adiciona tarefa
app.post('/add', (req, res) => {
  const { descricao } = req.body;
  db.run('INSERT INTO tarefas (descricao) VALUES (?)', [descricao], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

// Marcar como concluída
app.post('/concluir/:id', (req, res) => {
  const id = req.params.id;
  db.run('UPDATE tarefas SET concluida = 1 WHERE id = ?', [id], (err) => {
    if (err) throw err;
    res.redirect('/');
  });
});

app.listen(3000, () => {
  console.log('Servidor rodando em http://localhost:3000');
});
